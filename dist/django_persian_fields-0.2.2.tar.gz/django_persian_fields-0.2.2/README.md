Django model fields that is needed in Iran.
some examples, Iso Iran mobile, postal code, and so on